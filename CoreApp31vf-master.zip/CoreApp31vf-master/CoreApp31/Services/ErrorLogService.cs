﻿using CoreApp31.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreApp31.Services
{
    public class ErrorLogService : IService<ErrorLog, int>
    {
        private readonly VodafoneErDbContext ctx;

        public ErrorLogService(VodafoneErDbContext ctx)
        {
            this.ctx = ctx;
        }

        public async Task<ErrorLog> CreateAsync(ErrorLog entity)
        {
            var res = await ctx.ErrorLogs.AddAsync(entity);
            await ctx.SaveChangesAsync();
            return res.Entity;
        }

        public Task<bool> DeleteAsync(int id)
        {
            return null;
        }

        public Task<IEnumerable<ErrorLog>> GetAsync()
        {
            return null;
        }

        public Task<ErrorLog> GetAsync(int id)
        {
            return null;
        }

        public Task<ErrorLog> UpdateAsync(int id, ErrorLog entity)
        {
            return null; 
        }
    }
}
