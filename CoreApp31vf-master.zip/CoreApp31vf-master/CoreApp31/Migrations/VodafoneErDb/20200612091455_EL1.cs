﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CoreApp31.Migrations.VodafoneErDb
{
    public partial class EL1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ErrorLogs",
                columns: table => new
                {
                    ErrorLogId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ControllerName = table.Column<string>(maxLength: 100, nullable: false),
                    ActionName = table.Column<string>(maxLength: 100, nullable: true),
                    ExType = table.Column<string>(maxLength: 500, nullable: true),
                    ExMessage = table.Column<string>(nullable: true),
                    ExDateTime = table.Column<string>(nullable: true),
                    StackTrace = table.Column<string>(nullable: true),
                    CreatedOn = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ErrorLogs", x => x.ErrorLogId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ErrorLogs");
        }
    }
}
