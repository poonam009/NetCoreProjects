﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CoreApp31.Migrations
{
    public partial class ErrorLog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ErrorLogs",
                columns: table => new
                {
                    ErrorLogId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ControllerName = table.Column<string>(maxLength: 100, nullable: false),
                    ActionName = table.Column<string>(maxLength: 100, nullable: true),
                    ErrorMessage = table.Column<string>(maxLength: 500, nullable: true),
                    ViewName = table.Column<string>(maxLength: 500, nullable: true),
                    Result = table.Column<string>(maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ErrorLogs", x => x.ErrorLogId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ErrorLogs");
        }
    }
}
