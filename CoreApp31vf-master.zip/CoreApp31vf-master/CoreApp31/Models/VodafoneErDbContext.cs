﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreApp31.Models
{
    public class VodafoneErDbContext : DbContext
    {
       
        public DbSet<ErrorLog> ErrorLogs { get; set; }

        /// <summary>
        /// DbContextOptions<DbContext> will resolve all the dependencies on DbContext class e.g. Connection, DbSet, Command, etc
        /// </summary>
        public VodafoneErDbContext(DbContextOptions<VodafoneErDbContext> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }
    }
}
