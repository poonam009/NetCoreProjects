﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreApp31.Models;
using CoreApp31.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CoreApp31.Controllers
{
    public class ProductController : Controller
    {
        private readonly IService<Product, int> prtService;
        private readonly IService<Category, int> catService;
        public ProductController(IService<Product, int> prtService, IService<Category, int> catService)
        {
            this.prtService = prtService;
            this.catService = catService;

        }
        public async Task<IActionResult> Index()
        {
            var prd = await prtService.GetAsync();
            return View(prd);
        }

        public async Task<IActionResult> CreateAsync()
        {
            // Define a ViewBag that will pass the List of Categories to the Create View
            ViewBag.CategoryRowId = new SelectList(await catService.GetAsync(), "CategoryRowId", "CategoryName");
            return View(new Product());
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            try
            {
                // validate the model
                if (ModelState.IsValid)
                {
                    product = await prtService.CreateAsync(product);
                    return RedirectToAction("Index");
                }
                ViewBag.CategoryRowId = new SelectList(await catService.GetAsync(), "CategoryRowId", "CategoryName");
                return View(product); // stey on Same View with validation error messages
            }
            catch (Exception ex)
            {
                // redirect to error view
                return View("Error");
            }
        }
        public async Task<IActionResult> Edit(int id)
        {
            ViewBag.CategoryRowId = new SelectList(await catService.GetAsync(), "CategoryRowId", "CategoryName");
            var cat = await prtService.GetAsync(id);
            return View(cat);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            try
            {
                // validate the model
                if (ModelState.IsValid)
                {
                    product = await prtService.UpdateAsync(id, product);
                    return RedirectToAction("Index");
                }
                return View(product); // stey on Same View with validation error messages
            }
            catch (Exception ex)
            {
                // redirect to error view
                return View("Error");
            }
        }

        public async Task<IActionResult> Delete(int id)
        {
            var cat = await prtService.DeleteAsync(id);
            return RedirectToAction("Index");
        }
    }
}